﻿namespace qlts.Datas
{
    public class BusinessErrorMessages
    {
        public const string CategoryNotFound = "Không tìm thấy danh mục";
        public const string BusinessError = "Có lỗi xảy ra. Vui lòng thử lại!";
        public const string ERROR_MESSAGE_FIELD_NOT_NULL = "Trường yêu cầu bắt buộc.";
        public const string ERROR_MESSAGE_MAX_LENGTH_250 = "Độ dài trường tối thiểu 2 ký từ và không vượt quá 250 ký tự";

    }
}